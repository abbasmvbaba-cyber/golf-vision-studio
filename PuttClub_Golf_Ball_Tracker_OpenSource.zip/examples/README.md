Place test videos in this folder.

Recommended test set:
1. bright range, slow shot
2. bright range, fast shot
3. low light
4. grass background
5. white sky/background
6. motion blur
7. camera shake
8. ball temporarily occluded

The tracker should be evaluated on all cases, not just the easiest video.
