import numpy as np
from scipy.interpolate import UnivariateSpline

def smooth_trajectory(points):
    """
    Smooth reliable observations while preserving temporal order.
    Returns a list of (x, y). Falls back to raw points when too few exist.
    """
    if len(points) < 5:
        return [(p.x, p.y) for p in points]

    t = np.array([p.t for p in points], dtype=float)
    x = np.array([p.x for p in points], dtype=float)
    y = np.array([p.y for p in points], dtype=float)

    # Remove duplicate timestamps.
    keep = np.r_[True, np.diff(t) > 1e-6]
    t, x, y = t[keep], x[keep], y[keep]

    if len(t) < 5:
        return list(zip(x.tolist(), y.tolist()))

    try:
        sx = UnivariateSpline(t, x, s=max(1.0, len(t) * 2.0))
        sy = UnivariateSpline(t, y, s=max(1.0, len(t) * 2.0))
        return list(zip(sx(t).tolist(), sy(t).tolist()))
    except Exception:
        return list(zip(x.tolist(), y.tolist()))

def reject_outliers(points, max_jump):
    if len(points) < 3:
        return points
    out = [points[0]]
    for p in points[1:]:
        prev = out[-1]
        d = ((p.x-prev.x)**2 + (p.y-prev.y)**2)**0.5
        if d <= max_jump or p.predicted:
            out.append(p)
    return out
