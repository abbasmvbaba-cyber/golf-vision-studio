from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Tuple

class TrackingState(str, Enum):
    WAITING_FOR_BALL = "WAITING_FOR_BALL"
    BALL_DETECTED = "BALL_DETECTED"
    BALL_LOCKED = "BALL_LOCKED"
    TRACKING = "TRACKING"
    TEMPORARILY_LOST = "TEMPORARILY_LOST"
    RECOVERING = "RECOVERING"
    BALL_RECOVERED = "BALL_RECOVERED"
    SHOT_FINISHED = "SHOT_FINISHED"

@dataclass
class BallCandidate:
    x: float
    y: float
    radius: float
    detector_confidence: float
    shape_score: float
    appearance_score: float
    motion_score: float = 0.0
    prediction_score: float = 0.0
    score: float = 0.0
    source: str = "opencv"

@dataclass
class TrackPoint:
    t: float
    x: float
    y: float
    confidence: float
    predicted: bool = False
    radius: float = 0.0

@dataclass
class TrackingResult:
    state: TrackingState
    ball: Optional[Tuple[float, float]]
    predicted: Optional[Tuple[float, float]]
    confidence: float
    trajectory: List[TrackPoint]
    diagnostics: dict = field(default_factory=dict)
