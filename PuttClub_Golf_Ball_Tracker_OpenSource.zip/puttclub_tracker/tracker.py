import math
import time
from collections import deque

import cv2
import numpy as np

from .config import TrackerConfig
from .detector import OpenCVBallDetector, YoloBallDetector
from .flow import OpticalFlowHelper
from .kalman import BallKalman
from .models import (
    BallCandidate, TrackPoint, TrackingResult, TrackingState
)
from .trajectory import smooth_trajectory, reject_outliers

class GolfBallTracker:
    def __init__(self, config=None):
        self.cfg = config or TrackerConfig()
        self.detector = OpenCVBallDetector(self.cfg)
        self.yolo = None
        if self.cfg.yolo_model:
            self.yolo = YoloBallDetector(self.cfg)
        self.flow = OpticalFlowHelper(self.cfg.optical_flow_points)
        self.kalman = BallKalman(
            self.cfg.process_noise,
            self.cfg.measurement_noise
        )

        self.state = TrackingState.WAITING_FOR_BALL
        self.history = deque(maxlen=self.cfg.trajectory_max_points)
        self.last_gray = None
        self.last_time = None
        self.last_position = None
        self.last_radius = 0.0
        self.missed = 0
        self.lock_hits = 0
        self.total_frames = 0
        self.detected_frames = 0
        self.last_confidence = 0.0
        self.fps_ema = 0.0

    def reset(self):
        self.__init__(self.cfg)

    def _roi(self, frame_shape, predicted):
        if predicted is None:
            return None
        h, w = frame_shape[:2]
        x, y = predicted
        vx, vy = 0.0, 0.0
        s = self.kalman.state()
        if s:
            vx, vy = s[2], s[3]
        speed = math.hypot(vx, vy)
        size = int(
            max(
                self.cfg.roi_min_size,
                min(self.cfg.roi_max_size,
                self.last_radius * 8 +
                speed * self.cfg.roi_velocity_scale +
                24
            )
        )
        x0 = max(0, int(x-size))
        y0 = max(0, int(y-size))
        x1 = min(w, int(x+size))
        y1 = min(h, int(y+size))
        return x0, y0, x1, y1

    def _score(self, candidate, predicted, optical_delta):
        if predicted is None:
            prediction_score = 0.5
        else:
            d = math.hypot(candidate.x-predicted[0], candidate.y-predicted[1])
            scale = max(10.0, self.last_radius * 8.0 + 20.0)
            prediction_score = max(0.0, 1.0 - d/scale)

        if self.last_position is None:
            motion_score = 0.5
        else:
            dx = candidate.x-self.last_position[0]
            dy = candidate.y-self.last_position[1]
            if optical_delta:
                od = math.hypot(
                    dx-optical_delta[0], dy-optical_delta[1]
                )
                motion_score = max(0.0, 1.0-od/max(10.0, self.last_radius*6))
            else:
                motion_score = min(1.0, math.hypot(dx,dy)/100.0)

        radius_score = 1.0
        if self.last_radius > 0:
            ratio = candidate.radius/(self.last_radius+1e-6)
            radius_score = max(0.0, 1.0-abs(math.log(max(ratio,1e-4)))*1.5)

        candidate.prediction_score = prediction_score
        candidate.motion_score = motion_score
        candidate.score = (
            self.cfg.w_detector * candidate.detector_confidence +
            self.cfg.w_prediction * prediction_score +
            self.cfg.w_motion * motion_score +
            self.cfg.w_radius * radius_score +
            self.cfg.w_appearance * candidate.appearance_score +
            self.cfg.w_shape * candidate.shape_score
        )
        return candidate

    def _best_candidate(self, candidates, predicted, optical_delta):
        if not candidates:
            return None
        scored = [self._score(c, predicted, optical_delta) for c in candidates]
        scored.sort(key=lambda c: c.score, reverse=True)
        best = scored[0]

        # Reject teleportation unless confidence is exceptionally strong.
        if self.last_position is not None:
            jump = math.hypot(
                best.x-self.last_position[0],
                best.y-self.last_position[1]
            )
            if jump > self.cfg.max_jump_px and best.score < 0.85:
                return None
        return best

    def process_frame(self, frame, timestamp_seconds=None):
        now = time.perf_counter() if timestamp_seconds is None else float(timestamp_seconds)
        self.total_frames += 1

        if self.last_time is None:
            dt = 1.0 / 60.0
        else:
            dt = max(1e-4, min(0.2, now-self.last_time))
        self.last_time = now

        fps = 1.0 / dt
        self.fps_ema = fps if self.fps_ema == 0 else self.fps_ema*0.9 + fps*0.1

        predicted = self.kalman.predict(dt)

        roi = self._roi(frame.shape, predicted) if predicted else None
        candidates = self.detector.detect(frame, roi=roi)

        if self.yolo:
            try:
                candidates += self.yolo.detect(frame, roi=roi)
            except Exception:
                pass

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        optical_delta = None
        if self.cfg.optical_flow_enabled and predicted and self.last_position is not None:
            optical_delta = self.flow.estimate(
                self.last_gray, gray, self.last_position, max(self.last_radius, 3)
            )

        best = self._best_candidate(candidates, predicted, optical_delta)

        accepted = False
        if best is not None:
            if predicted is not None:
                d = math.hypot(best.x-predicted[0], best.y-predicted[1])
                # During recovery allow a wider gate.
                gate = max(30.0, self.last_radius*10.0 + 40.0)
                accepted = d <= gate or best.score >= 0.80
            else:
                accepted = True

        predicted_output = predicted
        point = None

        if accepted:
            self.kalman.correct(best.x, best.y)
            self.last_position = (best.x, best.y)
            self.last_radius = best.radius
            self.last_confidence = best.score
            self.detected_frames += 1
            self.missed = 0
            self.lock_hits += 1

            if self.lock_hits < self.cfg.lock_after_detections:
                self.state = TrackingState.BALL_DETECTED
            else:
                if self.state in (
                    TrackingState.TEMPORARILY_LOST,
                    TrackingState.RECOVERING
                ):
                    self.state = TrackingState.BALL_RECOVERED
                else:
                    self.state = TrackingState.TRACKING
                    if self.lock_hits >= self.cfg.lock_after_detections:
                        self.state = TrackingState.BALL_LOCKED

            point = TrackPoint(
                t=now, x=best.x, y=best.y,
                confidence=best.score, predicted=False,
                radius=best.radius
            )
        else:
            self.missed += 1
            if predicted is not None and self.missed <= self.cfg.max_missed_frames:
                self.state = (
                    TrackingState.RECOVERING
                    if self.missed >= self.cfg.recovery_missed_frames
                    else TrackingState.TEMPORARILY_LOST
                )
                s = self.kalman.state()
                px, py = predicted
                radius = self.last_radius
                confidence = max(0.0, self.last_confidence * (0.92 ** self.missed))
                point = TrackPoint(
                    t=now, x=px, y=py,
                    confidence=confidence, predicted=True,
                    radius=radius
                )
            else:
                self.state = TrackingState.SHOT_FINISHED
                self.lock_hits = 0

        if point:
            self.history.append(point)

        self.last_gray = gray

        diagnostics = {
            "fps": round(self.fps_ema, 2),
            "frame": self.total_frames,
            "detected_frames": self.detected_frames,
            "missed_frames": self.missed,
            "ball_radius_px": round(self.last_radius, 2),
            "candidate_count": len(candidates),
            "roi": roi,
            "state": self.state.value,
            "confidence": round(self.last_confidence, 3),
            "kalman_state": self.kalman.state(),
        }

        raw = reject_outliers(list(self.history), self.cfg.max_jump_px)
        smoothed = smooth_trajectory(raw)

        return TrackingResult(
            state=self.state,
            ball=self.last_position if accepted else None,
            predicted=predicted_output,
            confidence=self.last_confidence,
            trajectory=raw,
            diagnostics={
                **diagnostics,
                "smoothed_trajectory": smoothed
            }
        )

    def annotate(self, frame, result):
        out = frame.copy()

        if self.cfg.debug:
            if result.diagnostics.get("roi"):
                x0,y0,x1,y1 = result.diagnostics["roi"]
                cv2.rectangle(out, (x0,y0), (x1,y1), (255,150,0), 1)

        # Raw/predicted trajectory
        pts = result.trajectory
        for i in range(1, len(pts)):
            p1 = (int(pts[i-1].x), int(pts[i-1].y))
            p2 = (int(pts[i].x), int(pts[i].y))
            thickness = 1 if pts[i].predicted else 2
            cv2.line(out, p1, p2, (0, 220, 255), thickness)

        # Smoothed trajectory
        sm = result.diagnostics.get("smoothed_trajectory", [])
        for i in range(1, len(sm)):
            cv2.line(
                out,
                (int(sm[i-1][0]), int(sm[i-1][1])),
                (int(sm[i][0]), int(sm[i][1])),
                (0, 255, 80), 3
            )

        if result.ball:
            x,y = map(int, result.ball)
            cv2.circle(out, (x,y), max(3,int(self.last_radius)), (0,255,0), 2)
            cv2.circle(out, (x,y), 2, (255,255,255), -1)

        if result.predicted:
            x,y = map(int, result.predicted)
            cv2.drawMarker(out, (x,y), (255,180,0), cv2.MARKER_CROSS, 14, 1)

        text = (
            f"{result.state.value} | "
            f"FPS {result.diagnostics['fps']:.1f} | "
            f"CONF {result.confidence:.2f} | "
            f"R {result.diagnostics['ball_radius_px']:.1f}px"
        )
        cv2.putText(out, text, (12,28), cv2.FONT_HERSHEY_SIMPLEX, 0.65,
                    (255,255,255), 2, cv2.LINE_AA)
        return out
