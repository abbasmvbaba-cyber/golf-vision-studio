import json
from dataclasses import asdict
from pathlib import Path

def save_result_json(result, path):
    payload = {
        "state": result.state.value,
        "ball": result.ball,
        "predicted": result.predicted,
        "confidence": result.confidence,
        "trajectory": [asdict(p) for p in result.trajectory],
        "diagnostics": result.diagnostics,
    }
    # NumPy scalar/tuple values may appear in diagnostics.
    def default(o):
        try:
            return o.item()
        except Exception:
            return str(o)

    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2, default=default)
