import argparse
import cv2

from .config import TrackerConfig
from .tracker import GolfBallTracker
from .io import save_result_json

def main():
    p = argparse.ArgumentParser(description="PuttClub Golf Ball Tracker")
    p.add_argument("--input", type=str)
    p.add_argument("--camera", type=int)
    p.add_argument("--output", type=str, default="output/tracked.mp4")
    p.add_argument("--json", type=str, default="output/shot.json")
    p.add_argument("--debug", action="store_true")
    p.add_argument("--yolo-model", type=str, default=None)
    args = p.parse_args()

    cfg = TrackerConfig(
        debug=args.debug,
        yolo_model=args.yolo_model
    )
    tracker = GolfBallTracker(cfg)

    if args.input:
        cap = cv2.VideoCapture(args.input)
    else:
        cap = cv2.VideoCapture(0 if args.camera is None else args.camera)

    if not cap.isOpened():
        raise RuntimeError("Could not open video/camera")

    fps = cap.get(cv2.CAP_PROP_FPS)
    if not fps or fps < 1:
        fps = 60.0

    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    Path = __import__("pathlib").Path
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)

    writer = cv2.VideoWriter(
        args.output,
        cv2.VideoWriter_fourcc(*"mp4v"),
        fps,
        (width, height)
    )

    frame_idx = 0
    last_result = None

    while True:
        ok, frame = cap.read()
        if not ok:
            break

        ts = frame_idx / fps
        result = tracker.process_frame(frame, ts)
        last_result = result
        annotated = tracker.annotate(frame, result)
        writer.write(annotated)

        if args.debug:
            cv2.imshow("PuttClub Golf Ball Tracker", annotated)
            if cv2.waitKey(1) & 0xFF == 27:
                break

        frame_idx += 1

    cap.release()
    writer.release()
    cv2.destroyAllWindows()

    if last_result:
        save_result_json(last_result, args.json)

if __name__ == "__main__":
    main()
