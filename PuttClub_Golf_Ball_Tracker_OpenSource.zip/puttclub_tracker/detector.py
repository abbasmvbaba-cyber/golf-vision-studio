import math
import cv2
import numpy as np
from .models import BallCandidate

class OpenCVBallDetector:
    """
    Lightweight candidate detector. It is deliberately permissive:
    temporal tracking decides which candidate is actually the ball.
    """

    def __init__(self, config):
        self.cfg = config

    def preprocess(self, frame):
        lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(
            clipLimit=self.cfg.clahe_clip,
            tileGridSize=self.cfg.clahe_grid
        )
        l = clahe.apply(l)
        enhanced = cv2.cvtColor(cv2.merge((l, a, b)), cv2.COLOR_LAB2BGR)
        return enhanced

    def detect(self, frame, roi=None, source="opencv"):
        if roi is not None:
            x0, y0, x1, y1 = roi
            crop = frame[y0:y1, x0:x1]
            if crop.size == 0:
                return []
        else:
            x0 = y0 = 0
            crop = frame

        proc = self.preprocess(crop)
        gray = cv2.cvtColor(proc, cv2.COLOR_BGR2GRAY)
        hsv = cv2.cvtColor(proc, cv2.COLOR_BGR2HSV)

        # White/bright object mask. Morphology removes isolated noise.
        mask = cv2.inRange(
            hsv,
            np.array([0, 0, int(self.cfg.min_brightness)], np.uint8),
            np.array([180, int(self.cfg.max_saturation), 255], np.uint8),
        )
        kernel = np.ones((3, 3), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        candidates = []

        for c in contours:
            area = cv2.contourArea(c)
            if area <= 0:
                continue
            peri = cv2.arcLength(c, True)
            circularity = 4.0 * math.pi * area / (peri * peri + 1e-6)
            (cx, cy), radius = cv2.minEnclosingCircle(c)

            if not (self.cfg.min_ball_radius_px <= radius <= self.cfg.max_ball_radius_px):
                continue

            bx = int(max(0, min(gray.shape[1]-1, cx)))
            by = int(max(0, min(gray.shape[0]-1, cy)))
            local = gray[
                max(0, by-int(radius)):min(gray.shape[0], by+int(radius)+1),
                max(0, bx-int(radius)):min(gray.shape[1], bx+int(radius)+1)
            ]
            if local.size == 0:
                continue

            brightness = float(np.mean(local)) / 255.0
            shape_score = float(max(0.0, min(1.0, circularity / 0.9)))
            appearance = float(max(0.0, min(1.0, brightness)))

            gx, gy = cx + x0, cy + y0
            candidates.append(BallCandidate(
                x=float(gx),
                y=float(gy),
                radius=float(radius),
                detector_confidence=appearance,
                shape_score=shape_score,
                appearance_score=appearance,
                source=source
            ))

        candidates.sort(key=lambda c: c.appearance_score * 0.7 + c.shape_score * 0.3, reverse=True)
        return candidates[:self.cfg.candidate_top_k]


class YoloBallDetector:
    def __init__(self, config):
        self.cfg = config
        self.model = None
        if config.yolo_model:
            from ultralytics import YOLO
            self.model = YOLO(config.yolo_model)

    def detect(self, frame, roi=None):
        if self.model is None:
            return []
        offset_x = offset_y = 0
        image = frame
        if roi:
            x0, y0, x1, y1 = roi
            image = frame[y0:y1, x0:x1]
            offset_x, offset_y = x0, y0

        results = self.model.predict(
            image,
            conf=self.cfg.yolo_confidence,
            imgsz=self.cfg.yolo_imgsz,
            verbose=False
        )

        out = []
        for r in results:
            if r.boxes is None:
                continue
            for box in r.boxes:
                xyxy = box.xyxy[0].cpu().numpy()
                conf = float(box.conf[0].cpu().numpy())
                x1, y1, x2, y2 = map(float, xyxy)
                cx = (x1+x2)/2 + offset_x
                cy = (y1+y2)/2 + offset_y
                rad = max(1.0, min(x2-x1, y2-y1)/2)
                out.append(BallCandidate(
                    cx, cy, rad, conf, 0.8, conf, source="yolo"
                ))
        return out
