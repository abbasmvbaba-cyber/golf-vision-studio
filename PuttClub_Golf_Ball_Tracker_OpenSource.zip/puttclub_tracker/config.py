from dataclasses import dataclass, field
from typing import Tuple

@dataclass
class TrackerConfig:
    # Detection
    min_ball_radius_px: float = 1.2
    max_ball_radius_px: float = 80.0
    min_circularity: float = 0.35
    min_brightness: float = 145.0
    max_saturation: float = 105.0
    candidate_top_k: int = 30

    # Temporal tracking
    max_missed_frames: int = 12
    recovery_missed_frames: int = 3
    trajectory_max_points: int = 600
    history_seconds: float = 8.0

    # Motion / Kalman
    process_noise: float = 2.0
    measurement_noise: float = 8.0
    max_jump_px: float = 250.0
    max_acceleration_px_s2: float = 50000.0

    # ROI
    roi_min_size: int = 48
    roi_max_size: int = 640
    roi_velocity_scale: float = 0.22
    roi_margin: float = 3.0

    # Candidate scoring
    w_detector: float = 0.40
    w_prediction: float = 0.20
    w_motion: float = 0.15
    w_radius: float = 0.10
    w_appearance: float = 0.10
    w_shape: float = 0.05

    # Optical flow
    optical_flow_enabled: bool = True
    optical_flow_points: int = 30

    # State
    lock_after_detections: int = 2
    unlock_after_misses: int = 12

    # Debug
    debug: bool = False
    draw_candidates: bool = False

    # Optional YOLO
    yolo_model: str | None = None
    yolo_confidence: float = 0.15
    yolo_imgsz: int = 1280

    # Color preprocessing
    clahe_clip: float = 2.0
    clahe_grid: Tuple[int, int] = (8, 8)
