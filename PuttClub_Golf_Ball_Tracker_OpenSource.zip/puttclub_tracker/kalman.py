import numpy as np
import cv2

class BallKalman:
    """
    Constant-velocity 2D Kalman filter.
    State: x, y, vx, vy
    """

    def __init__(self, process_noise=2.0, measurement_noise=8.0):
        self.kf = cv2.KalmanFilter(4, 2)
        self.kf.transitionMatrix = np.array([
            [1, 0, 1, 0],
            [0, 1, 0, 1],
            [0, 0, 1, 0],
            [0, 0, 0, 1],
        ], np.float32)
        self.kf.measurementMatrix = np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0],
        ], np.float32)
        self.kf.processNoiseCov = np.eye(4, dtype=np.float32) * process_noise
        self.kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * measurement_noise
        self.kf.errorCovPost = np.eye(4, dtype=np.float32) * 50
        self.initialized = False

    def set_dt(self, dt: float):
        dt = max(1e-4, min(float(dt), 0.2))
        self.kf.transitionMatrix[:] = np.array([
            [1, 0, dt, 0],
            [0, 1, 0, dt],
            [0, 0, 1, 0],
            [0, 0, 0, 1],
        ], np.float32)

    def initialize(self, x, y):
        self.kf.statePost = np.array([[x], [y], [0], [0]], np.float32)
        self.kf.statePre = self.kf.statePost.copy()
        self.initialized = True

    def predict(self, dt: float):
        if not self.initialized:
            return None
        self.set_dt(dt)
        p = self.kf.predict()
        return float(p[0]), float(p[1])

    def correct(self, x, y):
        if not self.initialized:
            self.initialize(x, y)
            return x, y
        m = np.array([[np.float32(x)], [np.float32(y)]], np.float32)
        p = self.kf.correct(m)
        return float(p[0]), float(p[1])

    def state(self):
        if not self.initialized:
            return None
        s = self.kf.statePost.reshape(-1)
        return tuple(map(float, s))
