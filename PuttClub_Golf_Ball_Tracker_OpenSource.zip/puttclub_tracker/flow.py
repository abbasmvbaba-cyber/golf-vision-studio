import cv2
import numpy as np

class OpticalFlowHelper:
    def __init__(self, max_points=30):
        self.max_points = max_points

    def estimate(self, previous_gray, current_gray, center, radius):
        if previous_gray is None or current_gray is None:
            return None

        x, y = center
        r = max(4, int(radius * 2))
        x0, y0 = max(0, int(x-r)), max(0, int(y-r))
        x1, y1 = min(previous_gray.shape[1], int(x+r)), min(previous_gray.shape[0], int(y+r))

        old = previous_gray[y0:y1, x0:x1]
        new = current_gray[y0:y1, x0:x1]
        if old.size == 0 or new.size == 0:
            return None

        pts = cv2.goodFeaturesToTrack(
            old, maxCorners=self.max_points,
            qualityLevel=0.01, minDistance=2
        )
        if pts is None:
            return None

        pts2, status, _ = cv2.calcOpticalFlowPyrLK(old, new, pts, None)
        if pts2 is None:
            return None

        good_old = pts[status == 1]
        good_new = pts2[status == 1]
        if len(good_old) < 2:
            return None

        displacement = np.median(good_new - good_old, axis=0)
        return float(displacement[0]), float(displacement[1])
