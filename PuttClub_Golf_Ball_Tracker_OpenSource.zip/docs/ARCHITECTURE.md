# Architecture

## Why temporal tracking?

Golf balls are tiny and fast. A single frame can contain too little evidence.
The tracker therefore treats detection as a noisy measurement and temporal motion
as a first-class signal.

## State machine

WAITING_FOR_BALL
-> BALL_DETECTED
-> BALL_LOCKED
-> TRACKING
-> TEMPORARILY_LOST
-> RECOVERING
-> BALL_RECOVERED
-> TRACKING
-> SHOT_FINISHED

## Detector/tracker separation

Detector answers:
"Which pixels could be the ball?"

Tracker answers:
"Which candidate is consistent with the ball I was already following?"

This prevents the detector from changing the ball identity whenever another white
object appears.

## ROI

The ROI expands with:
- predicted speed
- previous ball radius
- missed frames

The ROI contracts again when tracking confidence improves.

## Important engineering fact

No software can reconstruct visual information that the camera never captured.
If the ball occupies 1-2 pixels or is completely motion-blurred between frames,
the correct solution may require a faster shutter, higher FPS, better optics,
more light, or a second camera.
