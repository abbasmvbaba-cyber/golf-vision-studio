# Instructions for an AI Coding Agent

Build on this project instead of replacing its architecture blindly.

## Primary objective

Create a production-ready golf ball tracking module that can:
1. Detect a tiny fast golf ball.
2. Lock onto the ball after multiple consistent observations.
3. Track through short missed detections.
4. Predict motion with a Kalman filter.
5. Search a local predicted ROI instead of running expensive detection everywhere.
6. Recover the ball after temporary loss.
7. Reject visually similar white objects and impossible jumps.
8. Reconstruct a smooth trajectory from reliable + predicted points.
9. Expose machine-readable JSON diagnostics.

## Non-negotiable rules

- Never assume the camera is 240 FPS.
- Read actual FPS and timestamps.
- Never treat one-frame YOLO confidence as proof that the object is the ball.
- Do not connect raw detections blindly.
- Do not declare the ball lost after one missed frame.
- Do not permanently increase YOLO confidence to hide false positives.
- Do not use a full-frame detector on every frame when a local ROI is available.
- Keep the detector and tracker independent.
- Keep UI/camera/API adapters separate from tracking logic.
- Every important threshold must be configurable.

## Detection strategy

Use multiple signals:
- brightness/whiteness
- saturation
- circularity
- local contrast
- radius consistency
- temporal motion
- Kalman prediction distance
- optical flow
- detector confidence if a neural detector is installed

Motion blur must not automatically reject the ball. A fast golf ball can appear elongated or partially blurred.

## Tracking strategy

Every frame:
1. Calculate real dt.
2. Predict with Kalman.
3. Build a dynamic ROI around prediction.
4. Detect candidates in ROI.
5. Optionally run YOLO only in ROI.
6. Score candidates using temporal + visual evidence.
7. Correct Kalman when a candidate is accepted.
8. If no candidate is accepted, retain prediction for a limited number of frames.
9. Expand recovery search progressively.
10. Finish the shot only after recovery is exhausted.

## Trajectory

The visible tracer is a rendered representation, not simply a line between every raw detection.

Maintain:
- raw observations
- predicted observations
- confidence
- timestamps

Reject physically/temporally impossible points, then smooth the reliable sequence.

## Diagnostics

Always expose:
- actual FPS
- resolution
- ball radius in pixels
- number of observed frames
- missed frames
- confidence
- state
- ROI size
- detector source
- Kalman state

## Future extensions

The architecture should allow:
- TrackNet-style temporal heatmap detector
- custom golf-ball YOLO model
- camera calibration
- 2D-to-3D reconstruction
- launch angle
- carry estimate
- apex
- lateral deviation
- club/impact synchronization
- stereo cameras
- radar fusion

Do not fake physical measurements without calibration.
