# PuttClub Golf Ball Tracker

Open-source reference implementation for golf-ball detection, temporal tracking,
trajectory reconstruction, recovery and visualization from ordinary video.

## Architecture

Camera/video
  -> preprocessing
  -> candidate detection (OpenCV)
  -> optional YOLO detector
  -> temporal validation
  -> Kalman prediction/correction
  -> local ROI recovery
  -> optical-flow assistance
  -> trajectory smoothing
  -> overlay + JSON

This is a reference implementation for an AI coding agent. It is intentionally
modular so an agent can replace the detector, UI, camera layer, or model without
rewriting the tracker.

## Important limitation

A normal low-FPS camera cannot recover information that was never captured.
For a fast golf shot, high shutter speed, high FPS and enough ball pixels are
critical. The software therefore records diagnostics such as FPS, ball size,
missed frames and tracking confidence.

## Install

Python 3.10+ recommended.

    python -m venv .venv
    source .venv/bin/activate
    pip install -r requirements.txt

Optional YOLO support:

    pip install ultralytics

## Run

Video:

    python -m puttclub_tracker --input examples/shot.mp4 --output output/tracked.mp4 --debug

Webcam:

    python -m puttclub_tracker --camera 0 --debug

JSON output:

    python -m puttclub_tracker --input examples/shot.mp4 --output output/tracked.mp4 --json output/shot.json

## Agent integration

The main public API is:

    from puttclub_tracker import GolfBallTracker, TrackerConfig

    tracker = GolfBallTracker(config)
    result = tracker.process_frame(frame, timestamp_seconds)

`result` contains state, ball position, confidence, predicted position,
trajectory points and diagnostics.

## Open-source references

The design is informed by public/open-source work including:
- Efficient Golf Ball Detection and Tracking Based on CNN + Kalman Filter
- TrackNet-style temporal ball localization
- OpenCV/Kalman ball tracking projects

Those references should be studied separately and their licenses respected.
This repository's own code is MIT licensed.
